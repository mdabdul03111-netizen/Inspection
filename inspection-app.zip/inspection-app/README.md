# Inspection Web App

## Install
npm install

## Run
npm run dev

## Build
npm run build
